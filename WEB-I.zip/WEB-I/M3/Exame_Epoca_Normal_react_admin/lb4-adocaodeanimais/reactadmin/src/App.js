import { Admin, Resource } from "react-admin";
import lb4Provider from "react-admin-lb4";
import { AdoptionEdit, AdoptionList } from "./AdoptionList";
import { AnimalEdit, AnimalList } from "./AnimalList";
import { DonationEdit, DonationList } from "./DonationList";
import { PersonEdit, PersonList } from "./PersonList";
import { VolunteerEdit, VolunteerList } from "./VolunteerList";

const dataProvider = lb4Provider("http://[::1]:3000")

const App = () => (
  <Admin dataProvider={dataProvider}>
    <Resource name="animal" list={AnimalList} edit={AnimalEdit} />
    <Resource name="adoptions" list={AdoptionList} edit={AdoptionEdit} />
    <Resource name="donations" list={DonationList} edit={DonationEdit} />
    <Resource name="people" list={PersonList} edit={PersonEdit} />
    <Resource name="volunteers" list={VolunteerList} edit={VolunteerEdit} />
  </Admin>
)

export default App;
