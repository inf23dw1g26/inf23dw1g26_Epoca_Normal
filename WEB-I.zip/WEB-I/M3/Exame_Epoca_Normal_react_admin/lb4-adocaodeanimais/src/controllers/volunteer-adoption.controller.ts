import {
  Count,
  CountSchema,
  Filter,
  repository,
  Where,
} from '@loopback/repository';
import {
  del,
  get,
  getModelSchemaRef,
  getWhereSchemaFor,
  param,
  patch,
  post,
  requestBody,
} from '@loopback/rest';
import {
  Volunteer,
  Adoption,
} from '../models';
import {VolunteerRepository} from '../repositories';

export class VolunteerAdoptionController {
  constructor(
    @repository(VolunteerRepository) protected volunteerRepository: VolunteerRepository,
  ) { }

  @get('/volunteers/{id}/adoptions', {
    responses: {
      '200': {
        description: 'Array of Volunteer has many Adoption',
        content: {
          'application/json': {
            schema: {type: 'array', items: getModelSchemaRef(Adoption)},
          },
        },
      },
    },
  })
  async find(
    @param.path.number('id') id: number,
    @param.query.object('filter') filter?: Filter<Adoption>,
  ): Promise<Adoption[]> {
    return this.volunteerRepository.VolunteerAdoption(id).find(filter);
  }

  @post('/volunteers/{id}/adoptions', {
    responses: {
      '200': {
        description: 'Volunteer model instance',
        content: {'application/json': {schema: getModelSchemaRef(Adoption)}},
      },
    },
  })
  async create(
    @param.path.number('id') id: typeof Volunteer.prototype.id,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Adoption, {
            title: 'NewAdoptionInVolunteer',
            exclude: ['id'],
            optional: ['volunteerAdoptionId']
          }),
        },
      },
    }) adoption: Omit<Adoption, 'id'>,
  ): Promise<Adoption> {
    return this.volunteerRepository.VolunteerAdoption(id).create(adoption);
  }

  @patch('/volunteers/{id}/adoptions', {
    responses: {
      '200': {
        description: 'Volunteer.Adoption PATCH success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async patch(
    @param.path.number('id') id: number,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Adoption, {partial: true}),
        },
      },
    })
    adoption: Partial<Adoption>,
    @param.query.object('where', getWhereSchemaFor(Adoption)) where?: Where<Adoption>,
  ): Promise<Count> {
    return this.volunteerRepository.VolunteerAdoption(id).patch(adoption, where);
  }

  @del('/volunteers/{id}/adoptions', {
    responses: {
      '200': {
        description: 'Volunteer.Adoption DELETE success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async delete(
    @param.path.number('id') id: number,
    @param.query.object('where', getWhereSchemaFor(Adoption)) where?: Where<Adoption>,
  ): Promise<Count> {
    return this.volunteerRepository.VolunteerAdoption(id).delete(where);
  }
}
