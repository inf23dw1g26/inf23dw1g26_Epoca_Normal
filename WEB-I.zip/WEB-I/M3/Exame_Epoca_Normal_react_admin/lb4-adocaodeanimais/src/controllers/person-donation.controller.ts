import {
  Count,
  CountSchema,
  Filter,
  repository,
  Where,
} from '@loopback/repository';
import {
  del,
  get,
  getModelSchemaRef,
  getWhereSchemaFor,
  param,
  patch,
  post,
  requestBody,
} from '@loopback/rest';
import {
  Person,
  Donation,
} from '../models';
import {PersonRepository} from '../repositories';

export class PersonDonationController {
  constructor(
    @repository(PersonRepository) protected personRepository: PersonRepository,
  ) { }

  @get('/people/{id}/donations', {
    responses: {
      '200': {
        description: 'Array of Person has many Donation',
        content: {
          'application/json': {
            schema: {type: 'array', items: getModelSchemaRef(Donation)},
          },
        },
      },
    },
  })
  async find(
    @param.path.number('id') id: number,
    @param.query.object('filter') filter?: Filter<Donation>,
  ): Promise<Donation[]> {
    return this.personRepository.PersonDonation(id).find(filter);
  }

  @post('/people/{id}/donations', {
    responses: {
      '200': {
        description: 'Person model instance',
        content: {'application/json': {schema: getModelSchemaRef(Donation)}},
      },
    },
  })
  async create(
    @param.path.number('id') id: typeof Person.prototype.id,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Donation, {
            title: 'NewDonationInPerson',
            exclude: ['id'],
            optional: ['personDonationId']
          }),
        },
      },
    }) donation: Omit<Donation, 'id'>,
  ): Promise<Donation> {
    return this.personRepository.PersonDonation(id).create(donation);
  }

  @patch('/people/{id}/donations', {
    responses: {
      '200': {
        description: 'Person.Donation PATCH success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async patch(
    @param.path.number('id') id: number,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Donation, {partial: true}),
        },
      },
    })
    donation: Partial<Donation>,
    @param.query.object('where', getWhereSchemaFor(Donation)) where?: Where<Donation>,
  ): Promise<Count> {
    return this.personRepository.PersonDonation(id).patch(donation, where);
  }

  @del('/people/{id}/donations', {
    responses: {
      '200': {
        description: 'Person.Donation DELETE success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async delete(
    @param.path.number('id') id: number,
    @param.query.object('where', getWhereSchemaFor(Donation)) where?: Where<Donation>,
  ): Promise<Count> {
    return this.personRepository.PersonDonation(id).delete(where);
  }
}
