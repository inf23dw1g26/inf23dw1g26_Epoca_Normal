import { Datagrid, DateField, List, ReferenceField, TextField } from 'react-admin';

export const AnimalList = () => (
    <List>
        <Datagrid rowClick="edit">
            <TextField source="id" />
            <TextField source="name" />
            <DateField source="age" />
            <TextField source="typeAnimal" />
            <TextField source="breed" />
            <TextField source="description" />
            <ReferenceField source="adoptionId" reference="adoptions" />
        </Datagrid>
    </List>
);