import {Getter, inject} from '@loopback/core';
import {DefaultCrudRepository, HasOneRepositoryFactory, repository} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Adoption, Animal, AnimalRelations} from '../models';
import {AdoptionRepository} from './adoption.repository';

export class AnimalRepository extends DefaultCrudRepository<
  Animal,
  typeof Animal.prototype.id,
  AnimalRelations
> {

  public readonly adoption: HasOneRepositoryFactory<Adoption, typeof Animal.prototype.id>;

  constructor(
    @inject('datasources.db') dataSource: DbDataSource, @repository.getter('AdoptionRepository') protected adoptionRepositoryGetter: Getter<AdoptionRepository>,
  ) {
    super(Animal, dataSource);
    this.adoption = this.createHasOneRepositoryFactoryFor('adoption', adoptionRepositoryGetter);
    this.registerInclusionResolver('adoption', this.adoption.inclusionResolver);
  }
}
