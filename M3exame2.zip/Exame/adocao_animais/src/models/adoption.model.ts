import {Entity, hasMany, hasOne, model, property} from '@loopback/repository';
import {Animal} from './animal.model';
import {Volunteer} from './volunteer.model';

@model()
export class Adoption extends Entity {
  @property({
    type: 'number',
    id: true,
    generated: true,
  })
  id?: number;

  @property({
    type: 'number',
    required: true,
  })
  idAnimal: number;

  @property({
    type: 'string',
  })
  name?: string;

  @property({
    type: 'string',
    required: true,
  })
  address: string;

  @property({
    type: 'number',
    required: true,
  })
  idPerson: number;

  @property({
    type: 'number',
    required: true,
  })
  idVolunteer: number;

  @property({
    type: 'string',
  })
  description?: string;

  @hasMany(() => Animal)
  animals: Animal[];

  @property({
    type: 'number',
  })
  animalId?: number;

  @property({
    type: 'number',
  })
  volunteerId?: number;

  @hasOne(() => Volunteer)
  volunteer: Volunteer;

  constructor(data?: Partial<Adoption>) {
    super(data);
  }
}

export interface AdoptionRelations {
  // describe navigational properties here
}

export type AdoptionWithRelations = Adoption & AdoptionRelations;
