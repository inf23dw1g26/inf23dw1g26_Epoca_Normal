import {Entity, hasMany, model, property} from '@loopback/repository';
import {Adoption} from './adoption.model';

@model()
export class Volunteer extends Entity {
  @property({
    type: 'number',
    id: true,
    generated: true,
  })
  id?: number;

  @property({
    type: 'string',
  })
  name?: string;

  @property({
    type: 'number',
  })
  anoInicioVolunteering?: number;

  @property({
    type: 'string',
    required: true,
  })
  phoneNumber: string;

  @property({
    type: 'string',
  })
  address?: string;

  @hasMany(() => Adoption)
  adoption: Adoption[];

  @property({
    type: 'number',
  })
  adoptionId?: number;

  constructor(data?: Partial<Volunteer>) {
    super(data);
  }
}

export interface VolunteerRelations {
  // describe navigational properties here
}

export type VolunteerWithRelations = Volunteer & VolunteerRelations;
