import {Entity, model, property} from '@loopback/repository';

@model()
export class Donations extends Entity {
  @property({
    type: 'number',
    id: true,
    generated: true,
  })
  id?: number;

  @property({
    type: 'number',
    required: true,
  })
  idPerson: number;

  @property({
    type: 'string',
    required: true,
  })
  type: string;

  @property({
    type: 'number',
  })
  quantity?: number;


  constructor(data?: Partial<Donations>) {
    super(data);
  }
}

export interface DonationsRelations {
  // describe navigational properties here
}

export type DonationsWithRelations = Donations & DonationsRelations;
