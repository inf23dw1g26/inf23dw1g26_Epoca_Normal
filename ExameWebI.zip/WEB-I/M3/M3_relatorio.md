
## Adoção de animais

Este trabalho foi feito com loopback4, mysql e react admin.
A nossa base de dados contém várias tabelas, sendo estas: Animal, Voluntário, Pessoa, Adoção e Doação.
Cada uma destas tabelas contém 30 inserts.
Fizemos a conexão entre 3 containers, o loopback 4, o mysql e o react admin.
O loopback ficou na porta 3000, o react admin na porta 3006 e o mysql na 3306.
Tivemos problemas em colocar o script do mysql a meter os dados na base de dados o que deixa o react admin não funcional.