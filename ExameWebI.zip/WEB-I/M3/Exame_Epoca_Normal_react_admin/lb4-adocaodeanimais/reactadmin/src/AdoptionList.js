import { Datagrid, EditButton, List, NumberField, ReferenceField, TextField, Edit, NumberInput, ReferenceInput, SimpleForm, TextInput } from 'react-admin';

export const AdoptionList = () => (
    <List>
        <Datagrid rowClick="edit">
            <TextField source="id" />
            <NumberField source="idAnimal" />
            <TextField source="name" />
            <TextField source="address" />
            <NumberField source="idPerson" />
            <NumberField source="idVoluntario" />
            <TextField source="description" />
            <ReferenceField source="animalAdoptionId" reference="animalAdoptions" />
            <ReferenceField source="volunteerAdoptionId" reference="volunteerAdoptions" />
            <ReferenceField source="personAdoptionId" reference="personAdoptions" />
            <EditButton/>
        </Datagrid>
    </List>
);
export const AdoptionEdit = () => (
    <Edit>
        <SimpleForm>
            <TextInput source="id" />
            <NumberInput source="idAnimal" />
            <TextInput source="name" />
            <TextInput source="address" />
            <NumberInput source="idPerson" />
            <NumberInput source="idVoluntario" />
            <TextInput source="description" />
            <ReferenceInput source="animalAdoptionId" reference="animalAdoptions" />
            <ReferenceInput source="volunteerAdoptionId" reference="volunteerAdoptions" />
            <ReferenceInput source="personAdoptionId" reference="personAdoptions" />
        </SimpleForm>
    </Edit>
);