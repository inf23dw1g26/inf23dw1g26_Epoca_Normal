import { Datagrid, EditButton, List, NumberField, ReferenceField, TextField, Edit, NumberInput, ReferenceInput, SimpleForm, TextInput } from 'react-admin';

export const DonationList = () => (
    <List>
        <Datagrid rowClick="edit">
            <TextField source="id" />
            <NumberField source="idPerson" />
            <TextField source="type" />
            <NumberField source="quantity" />
            <ReferenceField source="personDonationId" reference="personDonations" />
            <EditButton/>
        </Datagrid>
    </List>
);
export const DonationEdit = () => (
    <Edit>
        <SimpleForm>
            <TextInput source="id" />
            <NumberInput source="idPerson" />
            <TextInput source="type" />
            <NumberInput source="quantity" />
            <ReferenceInput source="personDonationId" reference="personDonations" />
        </SimpleForm>
    </Edit>
);