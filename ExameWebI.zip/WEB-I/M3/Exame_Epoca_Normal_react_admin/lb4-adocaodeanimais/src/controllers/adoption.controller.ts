import {
  Count,
  CountSchema,
  Filter,
  FilterExcludingWhere,
  repository,
  Where,
} from '@loopback/repository';
import {
  post,
  param,
  get,
  getModelSchemaRef,
  patch,
  put,
  del,
  requestBody,
  response,
} from '@loopback/rest';
import {Adoption} from '../models';
import {AdoptionRepository} from '../repositories';

export class AdoptionController {
  constructor(
    @repository(AdoptionRepository)
    public adoptionRepository : AdoptionRepository,
  ) {}

  @post('/adoptions')
  @response(200, {
    description: 'Adoption model instance',
    content: {'application/json': {schema: getModelSchemaRef(Adoption)}},
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Adoption, {
            title: 'NewAdoption',
            exclude: ['id'],
          }),
        },
      },
    })
    adoption: Omit<Adoption, 'id'>,
  ): Promise<Adoption> {
    return this.adoptionRepository.create(adoption);
  }

  @get('/adoptions/count')
  @response(200, {
    description: 'Adoption model count',
    content: {'application/json': {schema: CountSchema}},
  })
  async count(
    @param.where(Adoption) where?: Where<Adoption>,
  ): Promise<Count> {
    return this.adoptionRepository.count(where);
  }

  @get('/adoptions')
  @response(200, {
    description: 'Array of Adoption model instances',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(Adoption, {includeRelations: true}),
        },
      },
    },
  })
  async find(
    @param.filter(Adoption) filter?: Filter<Adoption>,
  ): Promise<Adoption[]> {
    return this.adoptionRepository.find(filter);
  }

  @patch('/adoptions')
  @response(200, {
    description: 'Adoption PATCH success count',
    content: {'application/json': {schema: CountSchema}},
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Adoption, {partial: true}),
        },
      },
    })
    adoption: Adoption,
    @param.where(Adoption) where?: Where<Adoption>,
  ): Promise<Count> {
    return this.adoptionRepository.updateAll(adoption, where);
  }

  @get('/adoptions/{id}')
  @response(200, {
    description: 'Adoption model instance',
    content: {
      'application/json': {
        schema: getModelSchemaRef(Adoption, {includeRelations: true}),
      },
    },
  })
  async findById(
    @param.path.number('id') id: number,
    @param.filter(Adoption, {exclude: 'where'}) filter?: FilterExcludingWhere<Adoption>
  ): Promise<Adoption> {
    return this.adoptionRepository.findById(id, filter);
  }

  @patch('/adoptions/{id}')
  @response(204, {
    description: 'Adoption PATCH success',
  })
  async updateById(
    @param.path.number('id') id: number,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Adoption, {partial: true}),
        },
      },
    })
    adoption: Adoption,
  ): Promise<void> {
    await this.adoptionRepository.updateById(id, adoption);
  }

  @put('/adoptions/{id}')
  @response(204, {
    description: 'Adoption PUT success',
  })
  async replaceById(
    @param.path.number('id') id: number,
    @requestBody() adoption: Adoption,
  ): Promise<void> {
    await this.adoptionRepository.replaceById(id, adoption);
  }

  @del('/adoptions/{id}')
  @response(204, {
    description: 'Adoption DELETE success',
  })
  async deleteById(@param.path.number('id') id: number): Promise<void> {
    await this.adoptionRepository.deleteById(id);
  }
}
