import {
  Count,
  CountSchema,
  Filter,
  FilterExcludingWhere,
  repository,
  Where,
} from '@loopback/repository';
import {
  post,
  param,
  get,
  getModelSchemaRef,
  patch,
  put,
  del,
  requestBody,
  response,
} from '@loopback/rest';
import {Donation} from '../models';
import {DonationRepository} from '../repositories';

export class DonationController {
  constructor(
    @repository(DonationRepository)
    public donationRepository : DonationRepository,
  ) {}

  @post('/donations')
  @response(200, {
    description: 'Donation model instance',
    content: {'application/json': {schema: getModelSchemaRef(Donation)}},
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Donation, {
            title: 'NewDonation',
            exclude: ['id'],
          }),
        },
      },
    })
    donation: Omit<Donation, 'id'>,
  ): Promise<Donation> {
    return this.donationRepository.create(donation);
  }

  @get('/donations/count')
  @response(200, {
    description: 'Donation model count',
    content: {'application/json': {schema: CountSchema}},
  })
  async count(
    @param.where(Donation) where?: Where<Donation>,
  ): Promise<Count> {
    return this.donationRepository.count(where);
  }

  @get('/donations')
  @response(200, {
    description: 'Array of Donation model instances',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(Donation, {includeRelations: true}),
        },
      },
    },
  })
  async find(
    @param.filter(Donation) filter?: Filter<Donation>,
  ): Promise<Donation[]> {
    return this.donationRepository.find(filter);
  }

  @patch('/donations')
  @response(200, {
    description: 'Donation PATCH success count',
    content: {'application/json': {schema: CountSchema}},
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Donation, {partial: true}),
        },
      },
    })
    donation: Donation,
    @param.where(Donation) where?: Where<Donation>,
  ): Promise<Count> {
    return this.donationRepository.updateAll(donation, where);
  }

  @get('/donations/{id}')
  @response(200, {
    description: 'Donation model instance',
    content: {
      'application/json': {
        schema: getModelSchemaRef(Donation, {includeRelations: true}),
      },
    },
  })
  async findById(
    @param.path.number('id') id: number,
    @param.filter(Donation, {exclude: 'where'}) filter?: FilterExcludingWhere<Donation>
  ): Promise<Donation> {
    return this.donationRepository.findById(id, filter);
  }

  @patch('/donations/{id}')
  @response(204, {
    description: 'Donation PATCH success',
  })
  async updateById(
    @param.path.number('id') id: number,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Donation, {partial: true}),
        },
      },
    })
    donation: Donation,
  ): Promise<void> {
    await this.donationRepository.updateById(id, donation);
  }

  @put('/donations/{id}')
  @response(204, {
    description: 'Donation PUT success',
  })
  async replaceById(
    @param.path.number('id') id: number,
    @requestBody() donation: Donation,
  ): Promise<void> {
    await this.donationRepository.replaceById(id, donation);
  }

  @del('/donations/{id}')
  @response(204, {
    description: 'Donation DELETE success',
  })
  async deleteById(@param.path.number('id') id: number): Promise<void> {
    await this.donationRepository.deleteById(id);
  }
}
