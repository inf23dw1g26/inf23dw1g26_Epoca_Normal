import {
  Count,
  CountSchema,
  Filter,
  repository,
  Where,
} from '@loopback/repository';
import {
  del,
  get,
  getModelSchemaRef,
  getWhereSchemaFor,
  param,
  patch,
  post,
  requestBody,
} from '@loopback/rest';
import {
  Person,
  Adoption,
} from '../models';
import {PersonRepository} from '../repositories';

export class PersonAdoptionController {
  constructor(
    @repository(PersonRepository) protected personRepository: PersonRepository,
  ) { }

  @get('/people/{id}/adoptions', {
    responses: {
      '200': {
        description: 'Array of Person has many Adoption',
        content: {
          'application/json': {
            schema: {type: 'array', items: getModelSchemaRef(Adoption)},
          },
        },
      },
    },
  })
  async find(
    @param.path.number('id') id: number,
    @param.query.object('filter') filter?: Filter<Adoption>,
  ): Promise<Adoption[]> {
    return this.personRepository.PersonAdoption(id).find(filter);
  }

  @post('/people/{id}/adoptions', {
    responses: {
      '200': {
        description: 'Person model instance',
        content: {'application/json': {schema: getModelSchemaRef(Adoption)}},
      },
    },
  })
  async create(
    @param.path.number('id') id: typeof Person.prototype.id,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Adoption, {
            title: 'NewAdoptionInPerson',
            exclude: ['id'],
            optional: ['personAdoptionId']
          }),
        },
      },
    }) adoption: Omit<Adoption, 'id'>,
  ): Promise<Adoption> {
    return this.personRepository.PersonAdoption(id).create(adoption);
  }

  @patch('/people/{id}/adoptions', {
    responses: {
      '200': {
        description: 'Person.Adoption PATCH success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async patch(
    @param.path.number('id') id: number,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Adoption, {partial: true}),
        },
      },
    })
    adoption: Partial<Adoption>,
    @param.query.object('where', getWhereSchemaFor(Adoption)) where?: Where<Adoption>,
  ): Promise<Count> {
    return this.personRepository.PersonAdoption(id).patch(adoption, where);
  }

  @del('/people/{id}/adoptions', {
    responses: {
      '200': {
        description: 'Person.Adoption DELETE success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async delete(
    @param.path.number('id') id: number,
    @param.query.object('where', getWhereSchemaFor(Adoption)) where?: Where<Adoption>,
  ): Promise<Count> {
    return this.personRepository.PersonAdoption(id).delete(where);
  }
}
