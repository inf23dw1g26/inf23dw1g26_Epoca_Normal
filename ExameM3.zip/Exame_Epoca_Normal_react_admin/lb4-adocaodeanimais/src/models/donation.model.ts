import {Entity, model, property, hasOne} from '@loopback/repository';
import {Person} from './person.model';

@model()
export class Donation extends Entity {
  @property({
    type: 'number',
    id: true,
    generated: true,
  })
  id?: number;

  @property({
    type: 'number',
    required: true,
  })
  idPerson: number;

  @property({
    type: 'string',
    required: true,
  })
  type: string;

  @property({
    type: 'number',
  })
  quantity?: number;

  @property({
    type: 'number',
  })
  personDonationId?: number;

  @hasOne(() => Person, {keyTo: 'donationPersonId'})
  DonationPerson: Person;

  constructor(data?: Partial<Donation>) {
    super(data);
  }
}

export interface DonationRelations {
  // describe navigational properties here
}

export type DonationWithRelations = Donation & DonationRelations;
