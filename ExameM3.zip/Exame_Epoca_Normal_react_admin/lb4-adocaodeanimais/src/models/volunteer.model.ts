import {Entity, model, property, hasMany} from '@loopback/repository';
import {Adoption} from './adoption.model';

@model()
export class Volunteer extends Entity {
  @property({
    type: 'number',
    id: true,
    generated: true,
  })
  id?: number;

  @property({
    type: 'string',
  })
  name?: string;

  @property({
    type: 'number',
    required: true,
  })
  phoneNumber: number;

  @property({
    type: 'string',
    required: true,
  })
  address: string;

  @hasMany(() => Adoption, {keyTo: 'volunteerAdoptionId'})
  VolunteerAdoption: Adoption[];

  constructor(data?: Partial<Volunteer>) {
    super(data);
  }
}

export interface VolunteerRelations {
  // describe navigational properties here
}

export type VolunteerWithRelations = Volunteer & VolunteerRelations;
