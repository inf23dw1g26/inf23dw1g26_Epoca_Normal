import {inject, Getter} from '@loopback/core';
import {DefaultCrudRepository, repository, HasOneRepositoryFactory} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Donation, DonationRelations, Person} from '../models';
import {PersonRepository} from './person.repository';

export class DonationRepository extends DefaultCrudRepository<
  Donation,
  typeof Donation.prototype.id,
  DonationRelations
> {

  public readonly DonationPerson: HasOneRepositoryFactory<Person, typeof Donation.prototype.id>;

  constructor(
    @inject('datasources.db') dataSource: DbDataSource, @repository.getter('PersonRepository') protected personRepositoryGetter: Getter<PersonRepository>,
  ) {
    super(Donation, dataSource);
    this.DonationPerson = this.createHasOneRepositoryFactoryFor('DonationPerson', personRepositoryGetter);
    this.registerInclusionResolver('DonationPerson', this.DonationPerson.inclusionResolver);
  }
}
