import {inject, Getter} from '@loopback/core';
import {DefaultCrudRepository, repository, HasOneRepositoryFactory} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Animal, AnimalRelations, Adoption} from '../models';
import {AdoptionRepository} from './adoption.repository';

export class AnimalRepository extends DefaultCrudRepository<
  Animal,
  typeof Animal.prototype.id,
  AnimalRelations
> {

  public readonly AnimalAdoption: HasOneRepositoryFactory<Adoption, typeof Animal.prototype.id>;

  constructor(
    @inject('datasources.db') dataSource: DbDataSource, @repository.getter('AdoptionRepository') protected adoptionRepositoryGetter: Getter<AdoptionRepository>,
  ) {
    super(Animal, dataSource);
    this.AnimalAdoption = this.createHasOneRepositoryFactoryFor('AnimalAdoption', adoptionRepositoryGetter);
    this.registerInclusionResolver('AnimalAdoption', this.AnimalAdoption.inclusionResolver);
  }
}
