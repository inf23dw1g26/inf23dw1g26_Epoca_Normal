import { Datagrid, EditButton, List, NumberField, ReferenceField, TextField, Edit, NumberInput, ReferenceInput, SimpleForm, TextInput } from 'react-admin';

export const AnimalList = () => (
    <List>
        <Datagrid rowClick="edit">
            <TextField source="id" />
            <TextField source="name" />
            <NumberField source="age" />
            <TextField source="typeAnimal" />
            <TextField source="breed" />
            <TextField source="description" />
            <ReferenceField source="adoptionAnimalId" reference="adoptionAnimals" />
            <EditButton/>
        </Datagrid>
    </List>
);
export const AnimalEdit = () => (
    <Edit>
        <SimpleForm>
            <TextInput source="id" />
            <TextInput source="name" />
            <NumberInput source="age" />
            <TextInput source="typeAnimal" />
            <TextInput source="breed" />
            <TextInput source="description" />
            <ReferenceInput source="adoptionAnimalId" reference="adoptionAnimals" />
        </SimpleForm>
    </Edit>
);