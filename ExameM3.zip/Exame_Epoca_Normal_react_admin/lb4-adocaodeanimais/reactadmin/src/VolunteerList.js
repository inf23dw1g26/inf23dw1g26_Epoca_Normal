import { Datagrid, EditButton, List, NumberField, TextField, Edit, NumberInput, SimpleForm, TextInput } from 'react-admin';

export const VolunteerList = () => (
    <List>
        <Datagrid rowClick="edit">
            <TextField source="id" />
            <TextField source="name" />
            <NumberField source="phoneNumber" />
            <TextField source="address" />
            <EditButton/>
        </Datagrid>
    </List>
);
export const VolunteerEdit = () => (
    <Edit>
        <SimpleForm>
            <TextInput source="id" />
            <TextInput source="name" />
            <NumberInput source="phoneNumber" />
            <TextInput source="address" />
        </SimpleForm>
    </Edit>
);