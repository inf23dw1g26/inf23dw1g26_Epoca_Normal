import { Datagrid, EditButton, List, NumberField, ReferenceField, TextField, Edit, NumberInput, ReferenceInput, SimpleForm, TextInput } from 'react-admin';

export const PersonList = () => (
    <List>
        <Datagrid rowClick="edit">
            <TextField source="id" />
            <TextField source="name" />
            <NumberField source="phoneNumber" />
            <TextField source="address" />
            <ReferenceField source="adoptionPersonId" reference="adoptionPerson" />
            <ReferenceField source="donationPersonId" reference="donationPerson" />
            <EditButton/>
        </Datagrid>
    </List>
);
export const PersonEdit = () => (
    <Edit>
        <SimpleForm>
            <TextInput source="id" />
            <TextInput source="name" />
            <NumberInput source="phoneNumber" />
            <TextInput source="address" />
            <ReferenceInput source="adoptionPersonId" reference="adoptionPerson" />
            <ReferenceInput source="donationPersonId" reference="donationPerson" />
        </SimpleForm>
    </Edit>
);