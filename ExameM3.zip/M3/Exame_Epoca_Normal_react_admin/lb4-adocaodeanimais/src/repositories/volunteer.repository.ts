import {inject, Getter} from '@loopback/core';
import {DefaultCrudRepository, repository, HasManyRepositoryFactory} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {volunteer, VolunteerRelations, adoption} from '../models';
import {AdoptionRepository} from './adoption.repository';

export class VolunteerRepository extends DefaultCrudRepository<
  volunteer,
  typeof volunteer.prototype.id,
  VolunteerRelations
> {

  public readonly VolunteerAdoption: HasManyRepositoryFactory<adoption, typeof volunteer.prototype.id>;

  constructor(
    @inject('datasources.db') dataSource: DbDataSource, @repository.getter('AdoptionRepository') protected adoptionRepositoryGetter: Getter<AdoptionRepository>,
  ) {
    super(volunteer, dataSource);
    this.VolunteerAdoption = this.createHasManyRepositoryFactoryFor('VolunteerAdoption', adoptionRepositoryGetter,);
    this.registerInclusionResolver('VolunteerAdoption', this.VolunteerAdoption.inclusionResolver);
  }
}
