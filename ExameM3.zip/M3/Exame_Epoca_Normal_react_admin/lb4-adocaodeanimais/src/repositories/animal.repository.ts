import {inject, Getter} from '@loopback/core';
import {DefaultCrudRepository, repository, HasOneRepositoryFactory} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {animal, AnimalRelations, adoption} from '../models';
import {AdoptionRepository} from './adoption.repository';

export class AnimalRepository extends DefaultCrudRepository<
  animal,
  typeof animal.prototype.id,
  AnimalRelations
> {

  public readonly AnimalAdoption: HasOneRepositoryFactory<adoption, typeof animal.prototype.id>;

  constructor(
    @inject('datasources.db') dataSource: DbDataSource, @repository.getter('AdoptionRepository') protected adoptionRepositoryGetter: Getter<AdoptionRepository>,
  ) {
    super(animal, dataSource);
    this.AnimalAdoption = this.createHasOneRepositoryFactoryFor('AnimalAdoption', adoptionRepositoryGetter);
    this.registerInclusionResolver('AnimalAdoption', this.AnimalAdoption.inclusionResolver);
  }
}
