import {inject, Getter} from '@loopback/core';
import {DefaultCrudRepository, repository, HasManyRepositoryFactory} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {person, PersonRelations, adoption, donation} from '../models';
import {AdoptionRepository} from './adoption.repository';
import {DonationRepository} from './donation.repository';

export class PersonRepository extends DefaultCrudRepository<
  person,
  typeof person.prototype.id,
  PersonRelations
> {

  public readonly PersonAdoption: HasManyRepositoryFactory<adoption, typeof person.prototype.id>;

  public readonly PersonDonation: HasManyRepositoryFactory<donation, typeof person.prototype.id>;

  constructor(
    @inject('datasources.db') dataSource: DbDataSource, @repository.getter('AdoptionRepository') protected adoptionRepositoryGetter: Getter<AdoptionRepository>, @repository.getter('DonationRepository') protected donationRepositoryGetter: Getter<DonationRepository>,
  ) {
    super(person, dataSource);
    this.PersonDonation = this.createHasManyRepositoryFactoryFor('PersonDonation', donationRepositoryGetter,);
    this.registerInclusionResolver('PersonDonation', this.PersonDonation.inclusionResolver);
    this.PersonAdoption = this.createHasManyRepositoryFactoryFor('PersonAdoption', adoptionRepositoryGetter,);
    this.registerInclusionResolver('PersonAdoption', this.PersonAdoption.inclusionResolver);
  }
}
