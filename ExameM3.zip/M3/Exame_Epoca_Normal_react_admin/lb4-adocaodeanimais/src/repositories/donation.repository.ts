import {inject, Getter} from '@loopback/core';
import {DefaultCrudRepository, repository, HasOneRepositoryFactory} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {donation, DonationRelations, person} from '../models';
import {PersonRepository} from './person.repository';

export class DonationRepository extends DefaultCrudRepository<
  donation,
  typeof donation.prototype.id,
  DonationRelations
> {

  public readonly DonationPerson: HasOneRepositoryFactory<person, typeof donation.prototype.id>;

  constructor(
    @inject('datasources.db') dataSource: DbDataSource, @repository.getter('PersonRepository') protected personRepositoryGetter: Getter<PersonRepository>,
  ) {
    super(donation, dataSource);
    this.DonationPerson = this.createHasOneRepositoryFactoryFor('DonationPerson', personRepositoryGetter);
    this.registerInclusionResolver('DonationPerson', this.DonationPerson.inclusionResolver);
  }
}
