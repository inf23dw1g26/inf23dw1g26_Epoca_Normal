import {inject, Getter} from '@loopback/core';
import {DefaultCrudRepository, repository, HasManyRepositoryFactory, HasOneRepositoryFactory} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {adoption, AdoptionRelations, animal, person} from '../models';
import {AnimalRepository} from './animal.repository';
import {PersonRepository} from './person.repository';

export class AdoptionRepository extends DefaultCrudRepository<
  adoption,
  typeof adoption.prototype.id,
  AdoptionRelations
> {

  public readonly AdoptionAnimal: HasManyRepositoryFactory<animal, typeof adoption.prototype.id>;

  public readonly AdoptionPerson: HasOneRepositoryFactory<person, typeof adoption.prototype.id>;

  constructor(
    @inject('datasources.db') dataSource: DbDataSource, @repository.getter('AnimalRepository') protected animalRepositoryGetter: Getter<AnimalRepository>, @repository.getter('PersonRepository') protected personRepositoryGetter: Getter<PersonRepository>,
  ) {
    super(adoption, dataSource);
    this.AdoptionPerson = this.createHasOneRepositoryFactoryFor('AdoptionPerson', personRepositoryGetter);
    this.registerInclusionResolver('AdoptionPerson', this.AdoptionPerson.inclusionResolver);
    this.AdoptionAnimal = this.createHasManyRepositoryFactoryFor('AdoptionAnimal', animalRepositoryGetter,);
    this.registerInclusionResolver('AdoptionAnimal', this.AdoptionAnimal.inclusionResolver);
  }
}
