import {Entity, model, property, hasMany} from '@loopback/repository';
import {adoption} from './adoption.model';
import {donation} from './donation.model';

@model()
export class person extends Entity {
  @property({
    type: 'number',
    id: true,
    generated: true,
  })
  id?: number;

  @property({
    type: 'string',
  })
  name?: string;

  @property({
    type: 'number',
  })
  phoneNumber?: number;

  @property({
    type: 'string',
    required: true,
  })
  address: string;

  @hasMany(() => adoption, {keyTo: 'personAdoptionId'})
  PersonAdoption: adoption[];

  @property({
    type: 'number',
  })
  adoptionPersonId?: number;

  @hasMany(() => donation, {keyTo: 'personDonationId'})
  PersonDonation: donation[];

  @property({
    type: 'number',
  })
  donationPersonId?: number;

  constructor(data?: Partial<person>) {
    super(data);
  }
}

export interface PersonRelations {
  // describe navigational properties here
}

export type PersonWithRelations = person & PersonRelations;
