import {Entity, model, property, hasOne} from '@loopback/repository';
import {adoption} from './adoption.model';

@model()
export class animal extends Entity {
  @property({
    type: 'number',
    id: true,
    generated: true,
  })
  id?: number;

  @property({
    type: 'string',
    required: true,
  })
  name: string;

  @property({
    type: 'number',
  })
  age?: number;

  @property({
    type: 'string',
    required: true,
  })
  typeAnimal: string;

  @property({
    type: 'string',
  })
  breed?: string;

  @property({
    type: 'string',
  })
  description?: string;

  @property({
    type: 'number',
  })
  adoptionAnimalId?: number;

  @hasOne(() => adoption, {keyTo: 'animalAdoptionId'})
  AnimalAdoption: adoption;

  constructor(data?: Partial<animal>) {
    super(data);
  }
}

export interface AnimalRelations {
  // describe navigational properties here
}

export type AnimalWithRelations = animal & AnimalRelations;
