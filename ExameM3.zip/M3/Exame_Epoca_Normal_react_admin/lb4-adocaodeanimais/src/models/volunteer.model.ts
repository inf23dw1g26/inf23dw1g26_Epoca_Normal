import {Entity, model, property, hasMany} from '@loopback/repository';
import {adoption} from './adoption.model';

@model()
export class volunteer extends Entity {
  @property({
    type: 'number',
    id: true,
    generated: true,
  })
  id?: number;

  @property({
    type: 'string',
  })
  name?: string;

  @property({
    type: 'number',
    required: true,
  })
  phoneNumber: number;

  @property({
    type: 'string',
    required: true,
  })
  address: string;

  @hasMany(() => adoption, {keyTo: 'volunteerAdoptionId'})
  VolunteerAdoption: adoption[];

  constructor(data?: Partial<volunteer>) {
    super(data);
  }
}

export interface VolunteerRelations {
  // describe navigational properties here
}

export type VolunteerWithRelations = volunteer & VolunteerRelations;
