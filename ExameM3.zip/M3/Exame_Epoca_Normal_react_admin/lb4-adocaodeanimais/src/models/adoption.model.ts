import {Entity, model, property, hasMany, hasOne} from '@loopback/repository';
import {animal} from './animal.model';
import {person} from './person.model';

@model()
export class adoption extends Entity {
  @property({
    type: 'number',
    id: true,
    generated: true,
  })
  id?: number;

  @property({
    type: 'number',
    required: true,
  })
  idAnimal: number;

  @property({
    type: 'string',
  })
  name?: string;

  @property({
    type: 'string',
  })
  address?: string;

  @property({
    type: 'number',
    required: true,
  })
  idPerson: number;

  @property({
    type: 'number',
    required: true,
  })
  idVoluntario: number;

  @property({
    type: 'string',
  })
  description?: string;

  @hasMany(() => animal, {keyTo: 'adoptionAnimalId'})
  AdoptionAnimal: animal[];

  @property({
    type: 'number',
  })
  animalAdoptionId?: number;

  @property({
    type: 'number',
  })
  volunteerAdoptionId?: number;

  @property({
    type: 'number',
  })
  personAdoptionId?: number;

  @hasOne(() => person, {keyTo: 'adoptionPersonId'})
  AdoptionPerson: person;

  constructor(data?: Partial<adoption>) {
    super(data);
  }
}

export interface AdoptionRelations {
  // describe navigational properties here
}

export type AdoptionWithRelations = adoption & AdoptionRelations;
