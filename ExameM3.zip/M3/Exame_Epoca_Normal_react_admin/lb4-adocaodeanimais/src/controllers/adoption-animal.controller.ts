import {
  Count,
  CountSchema,
  Filter,
  repository,
  Where,
} from '@loopback/repository';
import {
  del,
  get,
  getModelSchemaRef,
  getWhereSchemaFor,
  param,
  patch,
  post,
  requestBody,
} from '@loopback/rest';
import {
  adoption,
  animal,
} from '../models';
import {AdoptionRepository} from '../repositories';

export class AdoptionAnimalController {
  constructor(
    @repository(AdoptionRepository) protected adoptionRepository: AdoptionRepository,
  ) { }

  @get('/adoptions/{id}/animal', {
    responses: {
      '200': {
        description: 'Array of Adoption has many Animal',
        content: {
          'application/json': {
            schema: {type: 'array', items: getModelSchemaRef(animal)},
          },
        },
      },
    },
  })
  async find(
    @param.path.number('id') id: number,
    @param.query.object('filter') filter?: Filter<animal>,
  ): Promise<animal[]> {
    return this.adoptionRepository.AdoptionAnimal(id).find(filter);
  }

  @post('/adoptions/{id}/animal', {
    responses: {
      '200': {
        description: 'Adoption model instance',
        content: {'application/json': {schema: getModelSchemaRef(animal)}},
      },
    },
  })
  async create(
    @param.path.number('id') id: typeof adoption.prototype.id,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(animal, {
            title: 'NewAnimalInAdoption',
            exclude: ['id'],
            optional: ['adoptionAnimalId']
          }),
        },
      },
    }) animal: Omit<animal, 'id'>,
  ): Promise<animal> {
    return this.adoptionRepository.AdoptionAnimal(id).create(animal);
  }

  @patch('/adoptions/{id}/animal', {
    responses: {
      '200': {
        description: 'Adoption.Animal PATCH success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async patch(
    @param.path.number('id') id: number,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(animal, {partial: true}),
        },
      },
    })
    animal: Partial<animal>,
    @param.query.object('where', getWhereSchemaFor(animal)) where?: Where<animal>,
  ): Promise<Count> {
    return this.adoptionRepository.AdoptionAnimal(id).patch(animal, where);
  }

  @del('/adoptions/{id}/animal', {
    responses: {
      '200': {
        description: 'Adoption.Animal DELETE success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async delete(
    @param.path.number('id') id: number,
    @param.query.object('where', getWhereSchemaFor(animal)) where?: Where<animal>,
  ): Promise<Count> {
    return this.adoptionRepository.AdoptionAnimal(id).delete(where);
  }
}
