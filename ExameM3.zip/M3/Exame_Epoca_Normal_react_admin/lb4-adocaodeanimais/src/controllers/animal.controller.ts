import {
  Count,
  CountSchema,
  Filter,
  FilterExcludingWhere,
  repository,
  Where,
} from '@loopback/repository';
import {
  del,
  get,
  getModelSchemaRef,
  param,
  patch,
  post,
  put,
  requestBody,
  response,
} from '@loopback/rest';
import {animal} from '../models';
import {AnimalRepository} from '../repositories';

export class AnimalController {
  constructor(
    @repository(AnimalRepository)
    public animalRepository: AnimalRepository,
  ) { }

  @post('/animal')
  @response(200, {
    description: 'Animal model instance',
    content: {'application/json': {schema: getModelSchemaRef(animal)}},
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(animal, {
            title: 'NewAnimal',
            exclude: ['id'],
          }),
        },
      },
    })
    animal: Omit<animal, 'id'>,
  ): Promise<animal> {
    return this.animalRepository.create(animal);
  }

  @get('/animal/count')
  @response(200, {
    description: 'Animal model count',
    content: {'application/json': {schema: CountSchema}},
  })
  async count(
    @param.where(animal) where?: Where<animal>,
  ): Promise<Count> {
    return this.animalRepository.count(where);
  }

  @get('/animal')
  @response(200, {
    description: 'Array of Animal model instances',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(animal, {includeRelations: true}),
        },
      },
    },
  })
  async find(
    @param.filter(animal) filter?: Filter<animal>,
  ): Promise<animal[]> {
    return this.animalRepository.find(filter);
  }

  @patch('/animal')
  @response(200, {
    description: 'Animal PATCH success count',
    content: {'application/json': {schema: CountSchema}},
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(animal, {partial: true}),
        },
      },
    })
    animal: animal,
    @param.where(animal) where?: Where<animal>,
  ): Promise<Count> {
    return this.animalRepository.updateAll(animal, where);
  }

  @get('/animal/{id}')
  @response(200, {
    description: 'Animal model instance',
    content: {
      'application/json': {
        schema: getModelSchemaRef(animal, {includeRelations: true}),
      },
    },
  })
  async findById(
    @param.path.number('id') id: number,
    @param.filter(animal, {exclude: 'where'}) filter?: FilterExcludingWhere<animal>
  ): Promise<animal> {
    return this.animalRepository.findById(id, filter);
  }

  @patch('/animal/{id}')
  @response(204, {
    description: 'Animal PATCH success',
  })
  async updateById(
    @param.path.number('id') id: number,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(animal, {partial: true}),
        },
      },
    })
    animal: animal,
  ): Promise<void> {
    await this.animalRepository.updateById(id, animal);
  }

  @put('/animal/{id}')
  @response(204, {
    description: 'Animal PUT success',
  })
  async replaceById(
    @param.path.number('id') id: number,
    @requestBody() animal: animal,
  ): Promise<void> {
    await this.animalRepository.replaceById(id, animal);
  }

  @del('/animal/{id}')
  @response(204, {
    description: 'Animal DELETE success',
  })
  async deleteById(@param.path.number('id') id: number): Promise<void> {
    await this.animalRepository.deleteById(id);
  }
}
