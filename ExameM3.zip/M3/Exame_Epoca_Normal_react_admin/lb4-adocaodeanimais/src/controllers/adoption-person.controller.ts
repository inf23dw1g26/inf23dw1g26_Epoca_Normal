import {
  Count,
  CountSchema,
  Filter,
  repository,
  Where,
} from '@loopback/repository';
import {
  del,
  get,
  getModelSchemaRef,
  getWhereSchemaFor,
  param,
  patch,
  post,
  requestBody,
} from '@loopback/rest';
import {
  adoption,
  person,
} from '../models';
import {AdoptionRepository} from '../repositories';

export class AdoptionPersonController {
  constructor(
    @repository(AdoptionRepository) protected adoptionRepository: AdoptionRepository,
  ) { }

  @get('/adoptions/{id}/person', {
    responses: {
      '200': {
        description: 'Adoption has one Person',
        content: {
          'application/json': {
            schema: getModelSchemaRef(person),
          },
        },
      },
    },
  })
  async get(
    @param.path.number('id') id: number,
    @param.query.object('filter') filter?: Filter<person>,
  ): Promise<person> {
    return this.adoptionRepository.AdoptionPerson(id).get(filter);
  }

  @post('/adoptions/{id}/person', {
    responses: {
      '200': {
        description: 'Adoption model instance',
        content: {'application/json': {schema: getModelSchemaRef(person)}},
      },
    },
  })
  async create(
    @param.path.number('id') id: typeof adoption.prototype.id,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(person, {
            title: 'NewPersonInAdoption',
            exclude: ['id'],
            optional: ['adoptionPersonId']
          }),
        },
      },
    }) person: Omit<person, 'id'>,
  ): Promise<person> {
    return this.adoptionRepository.AdoptionPerson(id).create(person);
  }

  @patch('/adoptions/{id}/person', {
    responses: {
      '200': {
        description: 'Adoption.Person PATCH success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async patch(
    @param.path.number('id') id: number,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(person, {partial: true}),
        },
      },
    })
    person: Partial<person>,
    @param.query.object('where', getWhereSchemaFor(person)) where?: Where<person>,
  ): Promise<Count> {
    return this.adoptionRepository.AdoptionPerson(id).patch(person, where);
  }

  @del('/adoptions/{id}/person', {
    responses: {
      '200': {
        description: 'Adoption.Person DELETE success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async delete(
    @param.path.number('id') id: number,
    @param.query.object('where', getWhereSchemaFor(person)) where?: Where<person>,
  ): Promise<Count> {
    return this.adoptionRepository.AdoptionPerson(id).delete(where);
  }
}
