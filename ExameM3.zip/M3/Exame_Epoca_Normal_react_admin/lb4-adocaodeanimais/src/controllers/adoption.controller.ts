import {
  Count,
  CountSchema,
  Filter,
  FilterExcludingWhere,
  repository,
  Where,
} from '@loopback/repository';
import {
  post,
  param,
  get,
  getModelSchemaRef,
  patch,
  put,
  del,
  requestBody,
  response,
} from '@loopback/rest';
import {adoption} from '../models';
import {AdoptionRepository} from '../repositories';

export class AdoptionController {
  constructor(
    @repository(AdoptionRepository)
    public adoptionRepository : AdoptionRepository,
  ) {}

  @post('/adoptions')
  @response(200, {
    description: 'Adoption model instance',
    content: {'application/json': {schema: getModelSchemaRef(adoption)}},
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(adoption, {
            title: 'NewAdoption',
            exclude: ['id'],
          }),
        },
      },
    })
    adoption: Omit<adoption, 'id'>,
  ): Promise<adoption> {
    return this.adoptionRepository.create(adoption);
  }

  @get('/adoptions/count')
  @response(200, {
    description: 'Adoption model count',
    content: {'application/json': {schema: CountSchema}},
  })
  async count(
    @param.where(adoption) where?: Where<adoption>,
  ): Promise<Count> {
    return this.adoptionRepository.count(where);
  }

  @get('/adoptions')
  @response(200, {
    description: 'Array of Adoption model instances',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(adoption, {includeRelations: true}),
        },
      },
    },
  })
  async find(
    @param.filter(adoption) filter?: Filter<adoption>,
  ): Promise<adoption[]> {
    return this.adoptionRepository.find(filter);
  }

  @patch('/adoptions')
  @response(200, {
    description: 'Adoption PATCH success count',
    content: {'application/json': {schema: CountSchema}},
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(adoption, {partial: true}),
        },
      },
    })
    adoption: adoption,
    @param.where(adoption) where?: Where<adoption>,
  ): Promise<Count> {
    return this.adoptionRepository.updateAll(adoption, where);
  }

  @get('/adoptions/{id}')
  @response(200, {
    description: 'Adoption model instance',
    content: {
      'application/json': {
        schema: getModelSchemaRef(adoption, {includeRelations: true}),
      },
    },
  })
  async findById(
    @param.path.number('id') id: number,
    @param.filter(adoption, {exclude: 'where'}) filter?: FilterExcludingWhere<adoption>
  ): Promise<adoption> {
    return this.adoptionRepository.findById(id, filter);
  }

  @patch('/adoptions/{id}')
  @response(204, {
    description: 'Adoption PATCH success',
  })
  async updateById(
    @param.path.number('id') id: number,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(adoption, {partial: true}),
        },
      },
    })
    adoption: adoption,
  ): Promise<void> {
    await this.adoptionRepository.updateById(id, adoption);
  }

  @put('/adoptions/{id}')
  @response(204, {
    description: 'Adoption PUT success',
  })
  async replaceById(
    @param.path.number('id') id: number,
    @requestBody() adoption: adoption,
  ): Promise<void> {
    await this.adoptionRepository.replaceById(id, adoption);
  }

  @del('/adoptions/{id}')
  @response(204, {
    description: 'Adoption DELETE success',
  })
  async deleteById(@param.path.number('id') id: number): Promise<void> {
    await this.adoptionRepository.deleteById(id);
  }
}
