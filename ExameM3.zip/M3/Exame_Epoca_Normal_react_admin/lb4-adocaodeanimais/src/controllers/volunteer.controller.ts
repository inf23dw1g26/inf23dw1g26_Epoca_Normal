import {
  Count,
  CountSchema,
  Filter,
  FilterExcludingWhere,
  repository,
  Where,
} from '@loopback/repository';
import {
  post,
  param,
  get,
  getModelSchemaRef,
  patch,
  put,
  del,
  requestBody,
  response,
} from '@loopback/rest';
import {volunteer} from '../models';
import {VolunteerRepository} from '../repositories';

export class VolunteerController {
  constructor(
    @repository(VolunteerRepository)
    public volunteerRepository : VolunteerRepository,
  ) {}

  @post('/volunteers')
  @response(200, {
    description: 'Volunteer model instance',
    content: {'application/json': {schema: getModelSchemaRef(volunteer)}},
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(volunteer, {
            title: 'NewVolunteer',
            exclude: ['id'],
          }),
        },
      },
    })
    volunteer: Omit<volunteer, 'id'>,
  ): Promise<volunteer> {
    return this.volunteerRepository.create(volunteer);
  }

  @get('/volunteers/count')
  @response(200, {
    description: 'Volunteer model count',
    content: {'application/json': {schema: CountSchema}},
  })
  async count(
    @param.where(volunteer) where?: Where<volunteer>,
  ): Promise<Count> {
    return this.volunteerRepository.count(where);
  }

  @get('/volunteers')
  @response(200, {
    description: 'Array of Volunteer model instances',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(volunteer, {includeRelations: true}),
        },
      },
    },
  })
  async find(
    @param.filter(volunteer) filter?: Filter<volunteer>,
  ): Promise<volunteer[]> {
    return this.volunteerRepository.find(filter);
  }

  @patch('/volunteers')
  @response(200, {
    description: 'Volunteer PATCH success count',
    content: {'application/json': {schema: CountSchema}},
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(volunteer, {partial: true}),
        },
      },
    })
    volunteer: volunteer,
    @param.where(volunteer) where?: Where<volunteer>,
  ): Promise<Count> {
    return this.volunteerRepository.updateAll(volunteer, where);
  }

  @get('/volunteers/{id}')
  @response(200, {
    description: 'Volunteer model instance',
    content: {
      'application/json': {
        schema: getModelSchemaRef(volunteer, {includeRelations: true}),
      },
    },
  })
  async findById(
    @param.path.number('id') id: number,
    @param.filter(volunteer, {exclude: 'where'}) filter?: FilterExcludingWhere<volunteer>
  ): Promise<volunteer> {
    return this.volunteerRepository.findById(id, filter);
  }

  @patch('/volunteers/{id}')
  @response(204, {
    description: 'Volunteer PATCH success',
  })
  async updateById(
    @param.path.number('id') id: number,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(volunteer, {partial: true}),
        },
      },
    })
    volunteer: volunteer,
  ): Promise<void> {
    await this.volunteerRepository.updateById(id, volunteer);
  }

  @put('/volunteers/{id}')
  @response(204, {
    description: 'Volunteer PUT success',
  })
  async replaceById(
    @param.path.number('id') id: number,
    @requestBody() volunteer: volunteer,
  ): Promise<void> {
    await this.volunteerRepository.replaceById(id, volunteer);
  }

  @del('/volunteers/{id}')
  @response(204, {
    description: 'Volunteer DELETE success',
  })
  async deleteById(@param.path.number('id') id: number): Promise<void> {
    await this.volunteerRepository.deleteById(id);
  }
}
