import {
  Count,
  CountSchema,
  Filter,
  FilterExcludingWhere,
  repository,
  Where,
} from '@loopback/repository';
import {
  post,
  param,
  get,
  getModelSchemaRef,
  patch,
  put,
  del,
  requestBody,
  response,
} from '@loopback/rest';
import {donation} from '../models';
import {DonationRepository} from '../repositories';

export class DonationController {
  constructor(
    @repository(DonationRepository)
    public donationRepository : DonationRepository,
  ) {}

  @post('/donations')
  @response(200, {
    description: 'Donation model instance',
    content: {'application/json': {schema: getModelSchemaRef(donation)}},
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(donation, {
            title: 'NewDonation',
            exclude: ['id'],
          }),
        },
      },
    })
    donation: Omit<donation, 'id'>,
  ): Promise<donation> {
    return this.donationRepository.create(donation);
  }

  @get('/donations/count')
  @response(200, {
    description: 'Donation model count',
    content: {'application/json': {schema: CountSchema}},
  })
  async count(
    @param.where(donation) where?: Where<donation>,
  ): Promise<Count> {
    return this.donationRepository.count(where);
  }

  @get('/donations')
  @response(200, {
    description: 'Array of Donation model instances',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(donation, {includeRelations: true}),
        },
      },
    },
  })
  async find(
    @param.filter(donation) filter?: Filter<donation>,
  ): Promise<donation[]> {
    return this.donationRepository.find(filter);
  }

  @patch('/donations')
  @response(200, {
    description: 'Donation PATCH success count',
    content: {'application/json': {schema: CountSchema}},
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(donation, {partial: true}),
        },
      },
    })
    donation: donation,
    @param.where(donation) where?: Where<donation>,
  ): Promise<Count> {
    return this.donationRepository.updateAll(donation, where);
  }

  @get('/donations/{id}')
  @response(200, {
    description: 'Donation model instance',
    content: {
      'application/json': {
        schema: getModelSchemaRef(donation, {includeRelations: true}),
      },
    },
  })
  async findById(
    @param.path.number('id') id: number,
    @param.filter(donation, {exclude: 'where'}) filter?: FilterExcludingWhere<donation>
  ): Promise<donation> {
    return this.donationRepository.findById(id, filter);
  }

  @patch('/donations/{id}')
  @response(204, {
    description: 'Donation PATCH success',
  })
  async updateById(
    @param.path.number('id') id: number,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(donation, {partial: true}),
        },
      },
    })
    donation: donation,
  ): Promise<void> {
    await this.donationRepository.updateById(id, donation);
  }

  @put('/donations/{id}')
  @response(204, {
    description: 'Donation PUT success',
  })
  async replaceById(
    @param.path.number('id') id: number,
    @requestBody() donation: donation,
  ): Promise<void> {
    await this.donationRepository.replaceById(id, donation);
  }

  @del('/donations/{id}')
  @response(204, {
    description: 'Donation DELETE success',
  })
  async deleteById(@param.path.number('id') id: number): Promise<void> {
    await this.donationRepository.deleteById(id);
  }
}
