import {
  Count,
  CountSchema,
  Filter,
  repository,
  Where,
} from '@loopback/repository';
import {
  del,
  get,
  getModelSchemaRef,
  getWhereSchemaFor,
  param,
  patch,
  post,
  requestBody,
} from '@loopback/rest';
import {
  donation,
  person,
} from '../models';
import {DonationRepository} from '../repositories';

export class DonationPersonController {
  constructor(
    @repository(DonationRepository) protected donationRepository: DonationRepository,
  ) { }

  @get('/donations/{id}/person', {
    responses: {
      '200': {
        description: 'Donation has one Person',
        content: {
          'application/json': {
            schema: getModelSchemaRef(person),
          },
        },
      },
    },
  })
  async get(
    @param.path.number('id') id: number,
    @param.query.object('filter') filter?: Filter<person>,
  ): Promise<person> {
    return this.donationRepository.DonationPerson(id).get(filter);
  }

  @post('/donations/{id}/person', {
    responses: {
      '200': {
        description: 'Donation model instance',
        content: {'application/json': {schema: getModelSchemaRef(person)}},
      },
    },
  })
  async create(
    @param.path.number('id') id: typeof donation.prototype.id,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(person, {
            title: 'NewPersonInDonation',
            exclude: ['id'],
            optional: ['donationPersonId']
          }),
        },
      },
    }) person: Omit<person, 'id'>,
  ): Promise<person> {
    return this.donationRepository.DonationPerson(id).create(person);
  }

  @patch('/donations/{id}/person', {
    responses: {
      '200': {
        description: 'Donation.Person PATCH success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async patch(
    @param.path.number('id') id: number,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(person, {partial: true}),
        },
      },
    })
    person: Partial<person>,
    @param.query.object('where', getWhereSchemaFor(person)) where?: Where<person>,
  ): Promise<Count> {
    return this.donationRepository.DonationPerson(id).patch(person, where);
  }

  @del('/donations/{id}/person', {
    responses: {
      '200': {
        description: 'Donation.Person DELETE success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async delete(
    @param.path.number('id') id: number,
    @param.query.object('where', getWhereSchemaFor(person)) where?: Where<person>,
  ): Promise<Count> {
    return this.donationRepository.DonationPerson(id).delete(where);
  }
}
