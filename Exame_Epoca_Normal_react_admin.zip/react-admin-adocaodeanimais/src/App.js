import {Admin, Resource} from "react-admin";
import lb4Provider from "react-admin-lb4";
import { AnimalList, AnimalEdit } from "./AnimalList";
import { AdoptionList, AdoptionEdit } from "./AdoptionList";
import { DonationList, DonationEdit } from "./DonationList";
import { PersonList, PersonEdit } from "./PersonList";
import { VolunteerList, VolunteerEdit } from "./VolunteerList";

const dataProvider = lb4Provider("http://[::1]:3000")

const App = () => (
  <Admin dataProvider={dataProvider}>
    <Resource name="animals" list={AnimalList} edit={AnimalEdit}/>
    <Resource name="adoptions" list={AdoptionList} edit={AdoptionEdit}/>
    <Resource name="donations" list={DonationList} edit={DonationEdit}/>
    <Resource name="people" list={PersonList} edit={PersonEdit}/>
    <Resource name="volunteers" list={VolunteerList} edit={VolunteerEdit}/>
  </Admin>
)

export default App;
