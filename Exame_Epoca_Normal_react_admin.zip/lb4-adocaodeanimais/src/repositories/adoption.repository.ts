import {inject, Getter} from '@loopback/core';
import {DefaultCrudRepository, repository, HasManyRepositoryFactory, HasOneRepositoryFactory} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Adoption, AdoptionRelations, Animal, Person} from '../models';
import {AnimalRepository} from './animal.repository';
import {PersonRepository} from './person.repository';

export class AdoptionRepository extends DefaultCrudRepository<
  Adoption,
  typeof Adoption.prototype.id,
  AdoptionRelations
> {

  public readonly AdoptionAnimal: HasManyRepositoryFactory<Animal, typeof Adoption.prototype.id>;

  public readonly AdoptionPerson: HasOneRepositoryFactory<Person, typeof Adoption.prototype.id>;

  constructor(
    @inject('datasources.db') dataSource: DbDataSource, @repository.getter('AnimalRepository') protected animalRepositoryGetter: Getter<AnimalRepository>, @repository.getter('PersonRepository') protected personRepositoryGetter: Getter<PersonRepository>,
  ) {
    super(Adoption, dataSource);
    this.AdoptionPerson = this.createHasOneRepositoryFactoryFor('AdoptionPerson', personRepositoryGetter);
    this.registerInclusionResolver('AdoptionPerson', this.AdoptionPerson.inclusionResolver);
    this.AdoptionAnimal = this.createHasManyRepositoryFactoryFor('AdoptionAnimal', animalRepositoryGetter,);
    this.registerInclusionResolver('AdoptionAnimal', this.AdoptionAnimal.inclusionResolver);
  }
}
