import {inject, Getter} from '@loopback/core';
import {DefaultCrudRepository, repository, HasManyRepositoryFactory} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Person, PersonRelations, Adoption, Donation} from '../models';
import {AdoptionRepository} from './adoption.repository';
import {DonationRepository} from './donation.repository';

export class PersonRepository extends DefaultCrudRepository<
  Person,
  typeof Person.prototype.id,
  PersonRelations
> {

  public readonly PersonAdoption: HasManyRepositoryFactory<Adoption, typeof Person.prototype.id>;

  public readonly PersonDonation: HasManyRepositoryFactory<Donation, typeof Person.prototype.id>;

  constructor(
    @inject('datasources.db') dataSource: DbDataSource, @repository.getter('AdoptionRepository') protected adoptionRepositoryGetter: Getter<AdoptionRepository>, @repository.getter('DonationRepository') protected donationRepositoryGetter: Getter<DonationRepository>,
  ) {
    super(Person, dataSource);
    this.PersonDonation = this.createHasManyRepositoryFactoryFor('PersonDonation', donationRepositoryGetter,);
    this.registerInclusionResolver('PersonDonation', this.PersonDonation.inclusionResolver);
    this.PersonAdoption = this.createHasManyRepositoryFactoryFor('PersonAdoption', adoptionRepositoryGetter,);
    this.registerInclusionResolver('PersonAdoption', this.PersonAdoption.inclusionResolver);
  }
}
