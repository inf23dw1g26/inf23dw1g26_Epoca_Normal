import {inject, Getter} from '@loopback/core';
import {DefaultCrudRepository, repository, HasManyRepositoryFactory} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Volunteer, VolunteerRelations, Adoption} from '../models';
import {AdoptionRepository} from './adoption.repository';

export class VolunteerRepository extends DefaultCrudRepository<
  Volunteer,
  typeof Volunteer.prototype.id,
  VolunteerRelations
> {

  public readonly VolunteerAdoption: HasManyRepositoryFactory<Adoption, typeof Volunteer.prototype.id>;

  constructor(
    @inject('datasources.db') dataSource: DbDataSource, @repository.getter('AdoptionRepository') protected adoptionRepositoryGetter: Getter<AdoptionRepository>,
  ) {
    super(Volunteer, dataSource);
    this.VolunteerAdoption = this.createHasManyRepositoryFactoryFor('VolunteerAdoption', adoptionRepositoryGetter,);
    this.registerInclusionResolver('VolunteerAdoption', this.VolunteerAdoption.inclusionResolver);
  }
}
