import {Entity, model, property, hasMany} from '@loopback/repository';
import {Adoption} from './adoption.model';
import {Donation} from './donation.model';

@model()
export class Person extends Entity {
  @property({
    type: 'number',
    id: true,
    generated: true,
  })
  id?: number;

  @property({
    type: 'string',
  })
  name?: string;

  @property({
    type: 'number',
  })
  phoneNumber?: number;

  @property({
    type: 'string',
    required: true,
  })
  address: string;

  @hasMany(() => Adoption, {keyTo: 'personAdoptionId'})
  PersonAdoption: Adoption[];

  @property({
    type: 'number',
  })
  adoptionPersonId?: number;

  @hasMany(() => Donation, {keyTo: 'personDonationId'})
  PersonDonation: Donation[];

  @property({
    type: 'number',
  })
  donationPersonId?: number;

  constructor(data?: Partial<Person>) {
    super(data);
  }
}

export interface PersonRelations {
  // describe navigational properties here
}

export type PersonWithRelations = Person & PersonRelations;
