import {Entity, model, property, hasMany, hasOne} from '@loopback/repository';
import {Animal} from './animal.model';
import {Person} from './person.model';

@model()
export class Adoption extends Entity {
  @property({
    type: 'number',
    id: true,
    generated: true,
  })
  id?: number;

  @property({
    type: 'number',
    required: true,
  })
  idAnimal: number;

  @property({
    type: 'string',
  })
  name?: string;

  @property({
    type: 'string',
  })
  address?: string;

  @property({
    type: 'number',
    required: true,
  })
  idPerson: number;

  @property({
    type: 'number',
    required: true,
  })
  idVoluntario: number;

  @property({
    type: 'string',
  })
  description?: string;

  @hasMany(() => Animal, {keyTo: 'adoptionAnimalId'})
  AdoptionAnimal: Animal[];

  @property({
    type: 'number',
  })
  animalAdoptionId?: number;

  @property({
    type: 'number',
  })
  volunteerAdoptionId?: number;

  @property({
    type: 'number',
  })
  personAdoptionId?: number;

  @hasOne(() => Person, {keyTo: 'adoptionPersonId'})
  AdoptionPerson: Person;

  constructor(data?: Partial<Adoption>) {
    super(data);
  }
}

export interface AdoptionRelations {
  // describe navigational properties here
}

export type AdoptionWithRelations = Adoption & AdoptionRelations;
