import {Getter, inject} from '@loopback/core';
import {DefaultCrudRepository, HasManyRepositoryFactory, HasOneRepositoryFactory, repository} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Adoption, AdoptionRelations, Animal, Volunteer} from '../models';
import {AnimalRepository} from './animal.repository';
import {VolunteerRepository} from './volunteer.repository';

export class AdoptionRepository extends DefaultCrudRepository<
  Adoption,
  typeof Adoption.prototype.id,
  AdoptionRelations
> {

  public readonly animals: HasManyRepositoryFactory<Animal, typeof Adoption.prototype.id>;

  public readonly volunteer: HasOneRepositoryFactory<Volunteer, typeof Adoption.prototype.id>;

  constructor(
    @inject('datasources.db') dataSource: DbDataSource, @repository.getter('AnimalRepository') protected animalRepositoryGetter: Getter<AnimalRepository>, @repository.getter('VolunteerRepository') protected volunteerRepositoryGetter: Getter<VolunteerRepository>,
  ) {
    super(Adoption, dataSource);
    this.volunteer = this.createHasOneRepositoryFactoryFor('volunteer', volunteerRepositoryGetter);
    this.registerInclusionResolver('volunteer', this.volunteer.inclusionResolver);
    this.animals = this.createHasManyRepositoryFactoryFor('animals', animalRepositoryGetter,);
    this.registerInclusionResolver('animals', this.animals.inclusionResolver);
  }
}
