import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Donations, DonationsRelations} from '../models';

export class DonationsRepository extends DefaultCrudRepository<
  Donations,
  typeof Donations.prototype.id,
  DonationsRelations
> {
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
  ) {
    super(Donations, dataSource);
  }
}
