import {
  Count,
  CountSchema,
  Filter,
  repository,
  Where,
} from '@loopback/repository';
import {
  del,
  get,
  getModelSchemaRef,
  getWhereSchemaFor,
  param,
  patch,
  post,
  requestBody,
} from '@loopback/rest';
import {
  Animal,
  Adoption,
} from '../models';
import {AnimalRepository} from '../repositories';

export class AnimalAdoptionController {
  constructor(
    @repository(AnimalRepository) protected animalRepository: AnimalRepository,
  ) { }

  @get('/animals/{id}/adoption', {
    responses: {
      '200': {
        description: 'Animal has one Adoption',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Adoption),
          },
        },
      },
    },
  })
  async get(
    @param.path.number('id') id: number,
    @param.query.object('filter') filter?: Filter<Adoption>,
  ): Promise<Adoption> {
    return this.animalRepository.AnimalAdoption(id).get(filter);
  }

  @post('/animals/{id}/adoption', {
    responses: {
      '200': {
        description: 'Animal model instance',
        content: {'application/json': {schema: getModelSchemaRef(Adoption)}},
      },
    },
  })
  async create(
    @param.path.number('id') id: typeof Animal.prototype.id,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Adoption, {
            title: 'NewAdoptionInAnimal',
            exclude: ['id'],
            optional: ['animalAdoptionId']
          }),
        },
      },
    }) adoption: Omit<Adoption, 'id'>,
  ): Promise<Adoption> {
    return this.animalRepository.AnimalAdoption(id).create(adoption);
  }

  @patch('/animals/{id}/adoption', {
    responses: {
      '200': {
        description: 'Animal.Adoption PATCH success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async patch(
    @param.path.number('id') id: number,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Adoption, {partial: true}),
        },
      },
    })
    adoption: Partial<Adoption>,
    @param.query.object('where', getWhereSchemaFor(Adoption)) where?: Where<Adoption>,
  ): Promise<Count> {
    return this.animalRepository.AnimalAdoption(id).patch(adoption, where);
  }

  @del('/animals/{id}/adoption', {
    responses: {
      '200': {
        description: 'Animal.Adoption DELETE success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async delete(
    @param.path.number('id') id: number,
    @param.query.object('where', getWhereSchemaFor(Adoption)) where?: Where<Adoption>,
  ): Promise<Count> {
    return this.animalRepository.AnimalAdoption(id).delete(where);
  }
}
